# 🧠 Diabetes Prediction System

A simple machine learning model that predicts the likelihood of diabetes based on medical input features like BMI, glucose level, and age.

## 🚀 Tech Stack
- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Jupyter Notebook

## 📂 Project Structure
```
diabetes-prediction/
├── data/
│   └── diabetes.csv
├── notebook/
│   └── Diabetes_Predictor.ipynb
├── model/
├── README.md
└── requirements.txt
```

## 📊 Features
- Data preprocessing and visualization
- Train/Test split
- Logistic Regression model
- Accuracy evaluation

## 📝 How to Run
1. Clone the repo
2. Install dependencies:  
   `pip install -r requirements.txt`
3. Run the notebook:  
   `jupyter notebook notebook/Diabetes_Predictor.ipynb`
